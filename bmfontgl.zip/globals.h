#pragma once

#ifndef GLOBALS_H
#define GLOBALS_H

#ifdef __cplusplus
extern "C" {
#endif

HWND win_get_window(void);


#ifdef __cplusplus
} 
#endif
 

#endif